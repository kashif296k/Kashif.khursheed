KASHIF KHURSHEED — BILINGUAL PERSONAL WEBSITE
===============================================
This package includes index.html, a responsive personal-services website in English and Urdu.
Contact buttons are configured:
WhatsApp: https://wa.me/923027091396
Email: kashif_296@yahoo.com

Preview:
Open index.html in a web browser.

Publish free using GitHub Pages:
1. Sign in at https://github.com and create a repository.
2. For a personal site, name it YOUR-GITHUB-USERNAME.github.io.
3. Upload index.html at the root of the repository.
4. Go to Settings > Pages.
5. Under Build and deployment, choose Deploy from a branch, select main and /(root), then Save.
6. Open the URL GitHub Pages shows under Settings > Pages. Publishing can take a few minutes.
Official guide: https://docs.github.com/en/pages/quickstart

Important:
- This zip file is the website package; it does not mean the site is already live.
- Do not put private documents or passwords in a public website repository.
- You may buy a custom domain later, but it is not required to publish on the free github.io address.
